---
name: cloudbos-connection
description: Check Cloud BOS transport, version, and thin-client status without reading private masterBOS internals.
---

# cloudBOS Connection

Use this skill when the user asks to check Cloud BOS connection status, Cloud
BOS currentness, Cloud BOS transport, or whether the thin connector is bound.

## Workflow

0. Emit a visible speaker chain before any substantive output:

```text
BOS1.6> cloudBOS-connector> Codex> user>
```

If a project/app-specific capability is in scope, append or include that
capability speaker as well. Scoped/status-only use is still governed use.

1. Run:

```bash
python3 ../scripts/cloudbos_status.py
```

2. Return the rendered JSON summary and keep the visible speaker chain in the
   response.

3. If Cloud BOS is unavailable, say that Cloud BOS was not consulted and route
   high-risk governed work to blocked/provisional status.

## Rules

- Speaker mode is always on when this plugin is installed and active.
- Do not treat "scoped only", "status only", or "connection check only" as a
  reason to omit speaker prompts.
- Use `cloudBOS-connector>` for connector transport/status authority.
- Use `cloudBOS-public-connector>` for the public/beta package channel.
- Use `BOS-speaker-kernel>` when diagnosing missing speaker prompts.
- Do not read masterBOS `.bos` or DevPack internals.
- Do not print token values.
- Do not mutate local project files.
- Do not claim cloudBOS executed a change.
- Distinguish `cloudbos-connector` from cloudBOS itself.
