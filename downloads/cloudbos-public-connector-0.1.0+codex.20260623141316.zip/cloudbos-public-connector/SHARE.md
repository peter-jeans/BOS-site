# cloudBOS Connector Sharing Guide

Status: `FUTURE_READY_PUBLIC_DISTRIBUTION_PATH`

This is the real sharing path for beta users. It is different from the Codex
`Share cloudbos-connector` deep link, which only opens a local Codex share/export
screen for the plugin reference on the current machine.

## Public distribution name

The local developer plugin remains:

```text
cloudbos-connector
```

The future share/beta package is emitted as:

```text
cloudbos-public-connector
```

This prevents local developer installs from being confused with the future
public/beta connector channel.

## What beta users receive

Beta users should receive one of:

- a packaged `cloudbos-connector` zip produced by `scripts/package_plugin.py`;
- a private repository containing only this connector plugin;
- a future marketplace entry that points to the connector package or repository.

They should not receive local-machine links such as:

```text
codex://plugins/cloudbos-connector?marketplacePath=/Users/...
```

Those links are useful only on the machine that owns that local marketplace path.

## What beta users still need separately

The connector package does not include a Cloud BOS API key.

Each beta user needs their own token or entitlement route provisioned separately
and stored locally, for example:

- an environment variable such as `BOS_POC_TOKEN`;
- a platform secret in a governed app environment;
- a future account/entitlement flow.

Without a token, the connector should return `BLOCKED_NO_TOKEN`.

## Speaker mode

The public connector must always require visible speaker prompts when installed
and active.

Minimum public/beta chain:

```text
BOS1.6> cloudBOS-public-connector> Codex> user>
```

Status checks, scoped-only checks, no-token blocks, and transport diagnostics are
still governed connector responses. They should not drop the speaker chain.

## Safe install model

```text
plugin package -> user's local Codex plugin source -> user's Codex cache
user token -> user's local environment or secret store
Cloud BOS -> contacted only through the connector status/advice route
```

## Distribution boundary

The package must not include:

- `.bos`;
- DevPack internals;
- private masterBOS source;
- private prompt libraries;
- private scan engines;
- raw logs;
- raw receipts;
- token files;
- `.env` files;
- API keys or secrets;
- target app source or customer data.

## Future beta install outline

1. Send the connector package or repository link.
2. Ask the beta user to install it into their local Codex plugin source folder.
3. Ask them to add their own Cloud BOS token locally.
4. Ask them to run a connection check.
5. Confirm the output reports:

```text
connector: cloudbos-connector
mode: THIN_CLIENT_READ_ONLY
local_private_bos_read: false
devpack_read: false
token_value: REDACTED or null
```

## Current local developer command

From the `cloudbos-connector` plugin folder:

```bash
python3 scripts/package_plugin.py
```

The package script writes a `cloudbos-public-connector` zip and JSON manifest
under `dist/`.
