# cloudBOS Connector

Status: `THIN_CLIENT_SCAFFOLD`
Version: `0.1.0`

## Purpose

`cloudbos-connector` is the Codex plugin identity for connecting local projects
to cloudBOS without shipping private masterBOS internals.

This plugin is not cloudBOS itself. It is a local connector shell.

## Authority Model

```text
masterBOS = canonical source authority / mother ship
cloudBOS = always-on deployed mirror and distribution authority
cloudbos-connector = thin Codex client
client localBOS = lean project memory and receipts
```

Only masterBOS self-develops from masterBOS. Apps, plugins, Base44, Replit, and
future development surfaces should point to cloudBOS.

## What This Plugin May Do

- call allowlisted Cloud BOS endpoints;
- check transport and version status;
- request currentness, upgrade, template, manifest, and capability metadata;
- report whether local authority and Cloud BOS were consulted;
- help Codex prepare governed local actions after target alignment.

## What This Plugin Must Not Do

- include full BOS source;
- read or ship masterBOS `.bos`;
- read or ship DevPack internals;
- expose private prompt libraries;
- expose full scan engines or rule implementations;
- mutate target apps directly;
- push changes into masterBOS from client projects;
- log or display tokens.

## Current Script

```bash
python3 scripts/cloudbos_status.py
```

The script reads endpoint/token configuration from environment variables or an
explicit token file and prints redacted JSON status.

## Environment

Supported variables:

- `CLOUDBOS_ENDPOINT` or `BOS_ENDPOINT`
- `BOS_POC_TOKEN`, `BOS_CREATOR_TOKEN`, or `BOS_DEVELOPER_TOKEN`

Token values must remain local and ignored.
