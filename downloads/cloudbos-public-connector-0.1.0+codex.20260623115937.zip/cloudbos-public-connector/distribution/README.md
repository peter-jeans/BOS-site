# cloudBOS Connector Distribution

This folder holds public/beta-safe distribution materials for the future
`cloudbos-public-connector` Codex plugin package.

## Files

- `marketplace.personal.template.json` shows the shape of a local personal
  marketplace entry for the public connector package.

## Boundary

These files are templates only. They must not contain token values, private local
paths, `.bos`, DevPack material, raw receipts, source dumps, logs, or customer
data.

## Packaging

Run from the plugin root:

```bash
python3 scripts/package_plugin.py
```

The generated zip is named as `cloudbos-public-connector`. It is for future
controlled beta distribution and does not grant Cloud BOS access by itself;
users still need their own token/entitlement setup.
