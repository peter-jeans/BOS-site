#!/usr/bin/env python3
"""Package cloudbos-public-connector for future controlled beta sharing.

The package is intentionally small and rejects common private BOS, secret, and
local-environment files. It packages only the connector plugin, not Cloud BOS
itself and not masterBOS internals.
"""

from __future__ import annotations

import hashlib
import json
import re
import tempfile
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path


PLUGIN_ROOT = Path(__file__).resolve().parents[1]
DIST_DIR = PLUGIN_ROOT / "dist"
PUBLIC_PLUGIN_NAME = "cloudbos-public-connector"
PUBLIC_DISPLAY_NAME = "cloudBOS Public Connector"
FORBIDDEN_PARTS = {
    ".bos",
    "DEVPACK",
    "__pycache__",
    ".git",
    ".DS_Store",
}
FORBIDDEN_SUFFIXES = {
    ".env",
    ".pem",
    ".key",
    ".p12",
    ".pfx",
    ".log",
    ".sqlite",
    ".db",
}
TOKEN_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9_-]{20,}"),
    re.compile(r"(BOS_POC_TOKEN|BOS_CREATOR_TOKEN|BOS_DEVELOPER_TOKEN)\s*="),
    re.compile(r"Authorization:\s*Bearer\s+[A-Za-z0-9._-]{12,}", re.IGNORECASE),
    re.compile(r"(api[_-]?key|secret|token)\s*[:=]\s*['\"][^'\"]{8,}['\"]", re.IGNORECASE),
]
REQUIRED_FILES = [
    ".codex-plugin/plugin.json",
    "README.md",
    "SHARE.md",
    "skills/cloudbos-connection/SKILL.md",
    "skills/README.md",
    "scripts/cloudbos_status.py",
    "distribution/README.md",
    "distribution/marketplace.personal.template.json",
]


def rel(path: Path) -> str:
    return path.relative_to(PLUGIN_ROOT).as_posix()


def should_skip(path: Path) -> bool:
    relative = path.relative_to(PLUGIN_ROOT)
    if any(part in FORBIDDEN_PARTS for part in relative.parts):
        return True
    if any(path.name.endswith(suffix) for suffix in FORBIDDEN_SUFFIXES):
        return True
    if relative.parts and relative.parts[0] == "dist":
        return True
    return False


def assert_safe_text(path: Path) -> None:
    if path.suffix.lower() not in {".json", ".md", ".py", ".txt"}:
        return
    text = path.read_text(errors="replace")
    for pattern in TOKEN_PATTERNS:
        if pattern.search(text):
            raise SystemExit(f"Refusing to package possible secret in {rel(path)}")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    plugin_json = PLUGIN_ROOT / ".codex-plugin" / "plugin.json"
    plugin = json.loads(plugin_json.read_text())
    source_name = plugin["name"]
    name = PUBLIC_PLUGIN_NAME
    version = plugin["version"]

    missing = [item for item in REQUIRED_FILES if not (PLUGIN_ROOT / item).exists()]
    if missing:
        raise SystemExit(f"Missing required package files: {missing}")

    source_files: list[Path] = []
    for path in sorted(PLUGIN_ROOT.rglob("*")):
        if not path.is_file() or should_skip(path):
            continue
        assert_safe_text(path)
        source_files.append(path)

    DIST_DIR.mkdir(parents=True, exist_ok=True)
    safe_version = re.sub(r"[^A-Za-z0-9_.+-]+", "-", version)
    zip_path = DIST_DIR / f"{name}-{safe_version}.zip"
    manifest_path = DIST_DIR / f"{name}-{safe_version}.manifest.json"

    package_plugin = dict(plugin)
    package_plugin["name"] = PUBLIC_PLUGIN_NAME
    package_plugin["description"] = (
        "Public beta thin Codex client for connecting local projects to Cloud BOS "
        "without shipping private BOS internals."
    )
    package_plugin["keywords"] = sorted(set(package_plugin.get("keywords", []) + ["public-beta"]))
    package_plugin["interface"] = dict(package_plugin.get("interface", {}))
    package_plugin["interface"]["displayName"] = PUBLIC_DISPLAY_NAME
    package_plugin["interface"]["shortDescription"] = "Public beta Cloud BOS thin-client connector."
    package_plugin["interface"]["longDescription"] = (
        "Future public/beta distribution package for the Cloud BOS thin connector. "
        "It checks approved Cloud BOS endpoints and keeps local secrets, .bos, DevPack, "
        "private prompt libraries, scan engines, source dumps, logs, and customer data out of the package."
    )

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_root = Path(tmp)
            for path in source_files:
                relative = rel(path)
                target = tmp_root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                if relative == ".codex-plugin/plugin.json":
                    target.write_text(json.dumps(package_plugin, indent=2, sort_keys=False) + "\n")
                else:
                    target.write_bytes(path.read_bytes())
            for path in sorted(tmp_root.rglob("*")):
                if path.is_file():
                    archive.write(path, f"{name}/{path.relative_to(tmp_root).as_posix()}")

    generated_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    manifest = {
        "schema": "CLOUDBOS_CONNECTOR_PACKAGE_MANIFEST_V1",
        "generated_at": generated_at,
        "name": name,
        "source_plugin_name": source_name,
        "version": version,
        "status": "FUTURE_READY_DISTRIBUTION_PACKAGE",
        "distribution_channel": "PUBLIC_BETA_PREPARED",
        "zip": zip_path.name,
        "zip_sha256": sha256(zip_path),
        "file_count": len(source_files),
        "files": [rel(path) for path in source_files],
        "boundaries": [
            "no Cloud BOS token included",
            "no .bos included",
            "no DevPack included",
            "no private masterBOS internals included",
            "no raw logs or receipts included",
            "no target app source or customer data included",
        ],
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
