#!/usr/bin/env python3
"""Read-only Cloud BOS connector status check.

This script is intentionally thin. It does not read masterBOS .bos, DevPack,
operator runtime, private prompt libraries, or scan engines.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path


DEFAULT_ENDPOINT = "https://bos.peterjeans2.workers.dev"
TOKEN_KEYS = ("BOS_POC_TOKEN", "BOS_CREATOR_TOKEN", "BOS_DEVELOPER_TOKEN")


def parse_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw_line in path.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def load_token(token_file: Path | None) -> tuple[str, str]:
    for key in TOKEN_KEYS:
        value = os.environ.get(key, "").strip()
        if value:
            return value, f"environment:{key}"
    if token_file:
        values = parse_env_file(token_file)
        for key in TOKEN_KEYS:
            value = values.get(key, "").strip()
            if value:
                return value, f"file:{token_file}:{key}"
    return "", "missing"


def request_json(endpoint: str, path: str, token: str, timeout: float) -> dict:
    url = endpoint.rstrip("/") + path
    headers = {"accept": "application/json"}
    if token:
        headers["authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        content_type = response.headers.get("content-type", "")
        body = response.read().decode("utf-8", errors="replace")
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError:
        parsed = {"non_json_preview": body[:160]}
    return {
        "path": path,
        "url": url,
        "content_type": content_type,
        "json": parsed,
    }


def request_json_with_node(endpoint: str, path: str, token: str, timeout: float) -> dict:
    script = r"""
const endpoint = process.env.CLOUDBOS_ENDPOINT.replace(/\/$/, "");
const path = process.env.CLOUDBOS_PATH;
const token = process.env.CLOUDBOS_TOKEN;
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), Number(process.env.CLOUDBOS_TIMEOUT_MS || "10000"));
try {
  const response = await fetch(endpoint + path, {
    headers: {
      accept: "application/json",
      authorization: `Bearer ${token}`,
    },
    signal: controller.signal,
  });
  const contentType = response.headers.get("content-type") || "";
  const text = await response.text();
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    parsed = { non_json_preview: text.slice(0, 160) };
  }
  console.log(JSON.stringify({
    path,
    url: endpoint + path,
    status: response.status,
    content_type: contentType,
    json: parsed,
  }));
} finally {
  clearTimeout(timeout);
}
"""
    env = os.environ.copy()
    env.update(
        {
            "CLOUDBOS_ENDPOINT": endpoint,
            "CLOUDBOS_PATH": path,
            "CLOUDBOS_TOKEN": token,
            "CLOUDBOS_TIMEOUT_MS": str(int(timeout * 1000)),
        }
    )
    completed = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )
    return json.loads(completed.stdout)


def main() -> int:
    parser = argparse.ArgumentParser(description="Check Cloud BOS thin-client status.")
    parser.add_argument(
        "--endpoint",
        default=os.environ.get("CLOUDBOS_ENDPOINT") or os.environ.get("BOS_ENDPOINT") or DEFAULT_ENDPOINT,
    )
    parser.add_argument("--token-file", type=Path)
    parser.add_argument("--timeout", type=float, default=10.0)
    args = parser.parse_args()

    token, token_source = load_token(args.token_file)
    result = {
        "schema": "CLOUDBOS_CONNECTOR_STATUS_V1",
        "connector": "cloudbos-connector",
        "mode": "THIN_CLIENT_READ_ONLY",
        "endpoint": args.endpoint.rstrip("/"),
        "token_source": token_source,
        "token_present": bool(token),
        "token_value": "REDACTED" if token else None,
        "local_private_bos_read": False,
        "devpack_read": False,
        "masterbos_mutation_allowed": False,
        "cloudbos_consulted": False,
        "checks": [],
    }

    if not token:
        result["status"] = "BLOCKED_NO_TOKEN"
        print(json.dumps(result, indent=2, sort_keys=True))
        return 2

    for path in ("/bos/transport/check", "/bos/version"):
        try:
            transport = "python"
            try:
                check = request_json(args.endpoint, path, token, args.timeout)
            except urllib.error.URLError:
                check = request_json_with_node(args.endpoint, path, token, args.timeout)
                transport = "node-fetch-fallback"
            result["checks"].append(
                {
                    "path": path,
                    "status": "OK",
                    "transport": transport,
                    "http_status": check.get("status"),
                    "content_type": check["content_type"],
                    "payload_status": check["json"].get("status") if isinstance(check["json"], dict) else None,
                    "bos_version": (
                        check["json"].get("payload", {}).get("bos_version")
                        if isinstance(check["json"].get("payload"), dict)
                        else check["json"].get("bos_version")
                        if isinstance(check["json"], dict)
                        else None
                    ),
                }
            )
            result["cloudbos_consulted"] = True
        except urllib.error.HTTPError as exc:
            result["checks"].append({"path": path, "status": "HTTP_ERROR", "code": exc.code})
        except Exception as exc:  # noqa: BLE001 - report connector failure without leaking secrets.
            result["checks"].append({"path": path, "status": "ERROR", "error": type(exc).__name__})

    result["status"] = "READY" if result["cloudbos_consulted"] and all(c["status"] == "OK" for c in result["checks"]) else "PROVISIONAL"
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "READY" else 1


if __name__ == "__main__":
    raise SystemExit(main())
