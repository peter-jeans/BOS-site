# cloudBOS Connector Skills

- `cloudbos-connection`: checks transport/version status through the thin
  Cloud BOS connector path.
