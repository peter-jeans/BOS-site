---
name: cloudbos-connection
description: Check Cloud BOS transport, version, and thin-client status without reading private masterBOS internals.
---

# cloudBOS Connection

Use this skill when the user asks to check Cloud BOS connection status, Cloud
BOS currentness, Cloud BOS transport, or whether the thin connector is bound.

## Workflow

1. Run:

```bash
python3 ../scripts/cloudbos_status.py
```

2. Return the rendered JSON summary.

3. If Cloud BOS is unavailable, say that Cloud BOS was not consulted and route
   high-risk governed work to blocked/provisional status.

## Rules

- Do not read masterBOS `.bos` or DevPack internals.
- Do not print token values.
- Do not mutate local project files.
- Do not claim cloudBOS executed a change.
- Distinguish `cloudbos-connector` from cloudBOS itself.
